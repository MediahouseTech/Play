
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/stream-status.mjs
async function handler(request) {
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  const MUX_TOKEN_ID = process.env.MUX_TOKEN_ID || "7952c3b8-1fba-4bf8-b95a-219aee11cfe6";
  const MUX_TOKEN_SECRET = process.env.MUX_TOKEN_SECRET || "kIT/Bs5wfBOIkVjljFAFT/EjqxVFKJ+kmKKyFXXRuRIO3HyyES5OZUBpXwfmezViqwnLCPGN0E8";
  if (!MUX_TOKEN_ID || !MUX_TOKEN_SECRET) {
    return new Response(JSON.stringify({
      error: "Mux API credentials not configured"
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
  let liveStreamId;
  if (request.method === "GET") {
    const url = new URL(request.url);
    liveStreamId = url.searchParams.get("liveStreamId");
  } else if (request.method === "POST") {
    try {
      const body = await request.json();
      liveStreamId = body.liveStreamId;
    } catch (e) {
      const url = new URL(request.url);
      liveStreamId = url.searchParams.get("liveStreamId");
    }
  }
  if (!liveStreamId) {
    return new Response(JSON.stringify({
      error: "Missing liveStreamId parameter"
    }), {
      status: 400,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
  try {
    const auth = Buffer.from(`${MUX_TOKEN_ID}:${MUX_TOKEN_SECRET}`).toString("base64");
    const response = await fetch(`https://api.mux.com/video/v1/live-streams/${liveStreamId}`, {
      method: "GET",
      headers: {
        "Authorization": `Basic ${auth}`,
        "Content-Type": "application/json"
      }
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("[stream-status] Mux API error:", response.status, errorText);
      return new Response(JSON.stringify({
        error: "Failed to fetch stream status",
        details: errorText
      }), {
        status: response.status,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }
    const data = await response.json();
    const stream = data.data;
    return new Response(JSON.stringify({
      liveStreamId: stream.id,
      status: stream.status,
      isLive: stream.status === "active",
      playbackIds: stream.playback_ids?.map((p) => p.id) || [],
      reconnectWindow: stream.reconnect_window,
      createdAt: stream.created_at
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-cache, no-store, must-revalidate"
      }
    });
  } catch (error) {
    console.error("[stream-status] Error:", error);
    return new Response(JSON.stringify({
      error: "Internal server error",
      message: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
}
var config = {
  path: "/api/stream-status"
};
export {
  config,
  handler as default
};
