
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/recordings.mjs
import { getStore } from "@netlify/blobs";
var MUX_TOKEN_ID = "7952c3b8-1fba-4bf8-b95a-219aee11cfe6";
var MUX_TOKEN_SECRET = "kIT/Bs5wfBOIkVjljFAFT/EjqxVFKJ+kmKKyFXXRuRIO3HyyES5OZUBpXwfmezViqwnLCPGN0E8";
async function handler(request, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json",
    "Cache-Control": "no-store"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  try {
    const store = getStore("yabun-dashboard");
    const url = new URL(request.url);
    const action = url.searchParams.get("action");
    if (request.method === "GET" && !action) {
      let recordings = await store.get("recordings-index", { type: "json" }) || [];
      recordings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      return new Response(JSON.stringify({
        success: true,
        count: recordings.length,
        recordings
      }), { status: 200, headers });
    }
    if (request.method === "GET" && action === "download") {
      const assetId = url.searchParams.get("assetId");
      if (!assetId) {
        return new Response(JSON.stringify({
          success: false,
          error: "Missing assetId parameter"
        }), { status: 400, headers });
      }
      const auth = Buffer.from(`${MUX_TOKEN_ID}:${MUX_TOKEN_SECRET}`).toString("base64");
      const enableMasterResponse = await fetch(
        `https://api.mux.com/video/v1/assets/${assetId}/master-access`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Basic ${auth}`
          },
          body: JSON.stringify({ master_access: "temporary" })
        }
      );
      const assetResponse = await fetch(
        `https://api.mux.com/video/v1/assets/${assetId}`,
        {
          method: "GET",
          headers: {
            "Authorization": `Basic ${auth}`
          }
        }
      );
      if (!assetResponse.ok) {
        throw new Error(`Mux API error: ${assetResponse.status}`);
      }
      const assetData = await assetResponse.json();
      const asset = assetData.data;
      return new Response(JSON.stringify({
        success: true,
        assetId: asset.id,
        title: asset.meta?.title || "Untitled",
        externalId: asset.meta?.external_id || null,
        duration: asset.duration,
        masterAccess: asset.master_access,
        downloadUrl: asset.master?.url || null,
        playbackUrl: asset.playback_ids?.[0]?.id ? `https://stream.mux.com/${asset.playback_ids[0].id}.m3u8` : null,
        message: asset.master?.url ? "Download URL ready (expires in 24 hours)" : "Master URL is being prepared, try again in a few seconds"
      }), { status: 200, headers });
    }
    if (request.method === "GET" && action === "refresh") {
      let config = await store.get("config", { type: "json" });
      const knownStreamIds = [
        "spDSZGOT2fRmqVkMpvaiPMjnBD1qW8800ghXCHoJojBc"
        // Main Stage - hardcoded fallback
      ];
      if (config?.streams) {
        config.streams.forEach((s) => {
          if (s.liveStreamId && s.liveStreamId !== "ENTER_LIVE_STREAM_ID" && !knownStreamIds.includes(s.liveStreamId)) {
            knownStreamIds.push(s.liveStreamId);
          }
        });
      }
      const auth = Buffer.from(`${MUX_TOKEN_ID}:${MUX_TOKEN_SECRET}`).toString("base64");
      const assetsResponse = await fetch(
        "https://api.mux.com/video/v1/assets?limit=100",
        {
          method: "GET",
          headers: {
            "Authorization": `Basic ${auth}`
          }
        }
      );
      if (!assetsResponse.ok) {
        throw new Error(`Mux API error: ${assetsResponse.status}`);
      }
      const assetsData = await assetsResponse.json();
      const recordings = [];
      const stageNames = {
        "spDSZGOT2fRmqVkMpvaiPMjnBD1qW8800ghXCHoJojBc": "Main Stage",
        "x91mPV02jW00EhP6lECoopFnjTri2s02Zip474B9jYO6k00": "Old Test Stream"
      };
      if (config?.streams) {
        config.streams.forEach((s) => {
          if (s.liveStreamId && s.name) {
            stageNames[s.liveStreamId] = s.name;
          }
        });
      }
      for (const asset of assetsData.data) {
        if (asset.live_stream_id) {
          const stageName = stageNames[asset.live_stream_id] || "Unknown Stage";
          const createdDate = new Date(parseInt(asset.created_at) * 1e3);
          const sydneyTime = createdDate.toLocaleString("en-AU", {
            timeZone: "Australia/Sydney",
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            hour12: true
          });
          const durationMins = Math.round(asset.duration / 60);
          recordings.push({
            assetId: asset.id,
            playbackId: asset.playback_ids?.[0]?.id || null,
            liveStreamId: asset.live_stream_id,
            stageName,
            title: asset.meta?.title || `${stageName} - ${sydneyTime}`,
            externalId: asset.meta?.external_id || null,
            createdAt: asset.created_at,
            createdFormatted: sydneyTime,
            duration: asset.duration,
            durationStr: durationMins + " mins",
            status: asset.status
          });
        }
      }
      recordings.sort((a, b) => parseInt(b.createdAt) - parseInt(a.createdAt));
      await store.setJSON("recordings-index", recordings);
      return new Response(JSON.stringify({
        success: true,
        message: "Recordings index refreshed from Mux",
        count: recordings.length,
        recordings
      }), { status: 200, headers });
    }
    if (request.method === "POST") {
      const body = await request.json();
      const { action: postAction, assetId } = body;
      if (postAction === "delete" && assetId) {
        const auth = Buffer.from(`${MUX_TOKEN_ID}:${MUX_TOKEN_SECRET}`).toString("base64");
        const deleteResponse = await fetch(
          `https://api.mux.com/video/v1/assets/${assetId}`,
          {
            method: "DELETE",
            headers: {
              "Authorization": `Basic ${auth}`
            }
          }
        );
        if (!deleteResponse.ok && deleteResponse.status !== 404) {
          throw new Error(`Mux delete failed: ${deleteResponse.status}`);
        }
        let recordings = await store.get("recordings-index", { type: "json" }) || [];
        recordings = recordings.filter((r) => r.assetId !== assetId);
        await store.setJSON("recordings-index", recordings);
        return new Response(JSON.stringify({
          success: true,
          message: "Recording deleted",
          assetId
        }), { status: 200, headers });
      }
      if (postAction === "update" && assetId) {
        const { title, externalId, notes, tag } = body;
        const auth = Buffer.from(`${MUX_TOKEN_ID}:${MUX_TOKEN_SECRET}`).toString("base64");
        const passthrough = notes || tag ? JSON.stringify({ notes, tag }) : void 0;
        if (title || externalId) {
          const updateResponse = await fetch(
            `https://api.mux.com/video/v1/assets/${assetId}`,
            {
              method: "PATCH",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Basic ${auth}`
              },
              body: JSON.stringify({
                meta: {
                  title: title || void 0,
                  external_id: externalId || void 0
                },
                passthrough
              })
            }
          );
          if (!updateResponse.ok) {
            const errText = await updateResponse.text();
            console.error("[recordings] Mux update error:", errText);
          }
        }
        let recordings = await store.get("recordings-index", { type: "json" }) || [];
        const idx = recordings.findIndex((r) => r.assetId === assetId);
        if (idx !== -1) {
          if (title !== void 0) recordings[idx].title = title;
          if (externalId !== void 0) recordings[idx].externalId = externalId;
          if (notes !== void 0) recordings[idx].notes = notes;
          if (tag !== void 0) recordings[idx].tag = tag;
          await store.setJSON("recordings-index", recordings);
        }
        return new Response(JSON.stringify({
          success: true,
          message: "Recording updated",
          assetId
        }), { status: 200, headers });
      }
      return new Response(JSON.stringify({
        success: false,
        error: "Invalid POST action"
      }), { status: 400, headers });
    }
    return new Response(JSON.stringify({
      success: false,
      error: "Invalid request"
    }), { status: 400, headers });
  } catch (error) {
    console.error("[recordings] Error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), { status: 500, headers });
  }
}
export {
  handler as default
};
