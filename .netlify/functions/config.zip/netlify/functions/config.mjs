
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/config.mjs
import { getStore } from "@netlify/blobs";
var defaultConfig = {
  eventName: "Yabun Festival 2025",
  streamBaseUrl: "https://live-dashboard.bluehaze.studio/mux-stream/",
  expiryDate: "2026-01-27T23:59:00",
  producerPassword: "Live2Stream",
  eventInfo: {
    date: "Sunday 26 January 2025",
    callTime: "7:00 AM",
    liveStart: "10:00 AM",
    liveEnd: "6:00 PM",
    role: "Production Crew",
    brief: "Monitor your assigned stage. Report any audio/video issues to Scott immediately via WhatsApp.",
    whatsappLink: "https://chat.whatsapp.com/xxxxxxxxx",
    producerName: "Scott",
    producerPhone: "0412 XXX XXX"
  },
  streams: [
    { name: "Main Stage", playbackId: "", streamKey: "", rtmpUrl: "rtmp://global-live.mux.com:5222/app" },
    { name: "Yabun Yarns", playbackId: "", streamKey: "", rtmpUrl: "rtmp://global-live.mux.com:5222/app" },
    { name: "Corroboree", playbackId: "", streamKey: "", rtmpUrl: "rtmp://global-live.mux.com:5222/app" },
    { name: "Speak Out", playbackId: "", streamKey: "", rtmpUrl: "rtmp://global-live.mux.com:5222/app" }
  ],
  visibility: {
    vuMeters: true,
    streamStatus: true,
    duration: true,
    bitrate: false,
    viewers: false
  },
  defaultBandwidth: "medium"
};
var config_default = async (req, context) => {
  const store = getStore("dashboard-config");
  if (req.method === "GET") {
    try {
      const config2 = await store.get("config", { type: "json" });
      return new Response(JSON.stringify(config2 || defaultConfig), {
        headers: { "Content-Type": "application/json" }
      });
    } catch (error) {
      console.error("Error loading config:", error);
      return new Response(JSON.stringify(defaultConfig), {
        headers: { "Content-Type": "application/json" }
      });
    }
  }
  if (req.method === "POST") {
    try {
      const config2 = await req.json();
      await store.setJSON("config", config2);
      return new Response(JSON.stringify({ success: true }), {
        headers: { "Content-Type": "application/json" }
      });
    } catch (error) {
      console.error("Error saving config:", error);
      return new Response(JSON.stringify({ error: "Failed to save" }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
  }
  return new Response("Method not allowed", { status: 405 });
};
var config = {
  path: "/api/config"
};
export {
  config,
  config_default as default
};
