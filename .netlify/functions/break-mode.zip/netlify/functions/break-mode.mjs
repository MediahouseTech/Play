
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/break-mode.mjs
import { getStore } from "@netlify/blobs";
async function handler(request, context) {
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Cache-Control": "no-store, no-cache, must-revalidate"
      }
    });
  }
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json",
    "Cache-Control": "no-store, no-cache, must-revalidate"
  };
  try {
    const store = getStore("yabun-dashboard");
    if (request.method === "GET") {
      let breakState = await store.get("break-mode", { type: "json" });
      if (!breakState) {
        breakState = {
          "0": false,
          "1": false,
          "2": false,
          "3": false,
          fallbackPlaybackId: "mbX0201BRcVnkh802Fb00UHWbRUpNgV64lM029iBmuHLqe1g",
          lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
        };
        await store.setJSON("break-mode", breakState);
      }
      console.log("[break-mode] GET:", JSON.stringify(breakState));
      return new Response(JSON.stringify({
        success: true,
        breakMode: breakState
      }), { status: 200, headers });
    }
    if (request.method === "POST") {
      const body = await request.json();
      const { streamIndex, isOnBreak } = body;
      if (streamIndex === void 0 || isOnBreak === void 0) {
        return new Response(JSON.stringify({
          success: false,
          error: "Missing streamIndex or isOnBreak parameter"
        }), { status: 400, headers });
      }
      const index = String(streamIndex);
      if (!["0", "1", "2", "3"].includes(index)) {
        return new Response(JSON.stringify({
          success: false,
          error: "Invalid streamIndex. Must be 0-3."
        }), { status: 400, headers });
      }
      let breakState = await store.get("break-mode", { type: "json" });
      if (!breakState) {
        breakState = {
          "0": false,
          "1": false,
          "2": false,
          "3": false,
          fallbackPlaybackId: "mbX0201BRcVnkh802Fb00UHWbRUpNgV64lM029iBmuHLqe1g"
        };
      }
      breakState[index] = Boolean(isOnBreak);
      breakState.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
      breakState.updatedBy = body.updatedBy || "producer";
      await store.setJSON("break-mode", breakState);
      console.log(`[break-mode] POST: Stream ${index} set to ${isOnBreak ? "BREAK" : "LIVE"}`);
      return new Response(JSON.stringify({
        success: true,
        breakMode: breakState,
        message: `Stream ${index} is now ${isOnBreak ? "ON BREAK" : "LIVE"}`
      }), { status: 200, headers });
    }
    return new Response(JSON.stringify({
      success: false,
      error: "Method not allowed"
    }), { status: 405, headers });
  } catch (error) {
    console.error("[break-mode] Error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), { status: 500, headers });
  }
}
export {
  handler as default
};
